// Sample solution for the default "Demo Contest" problem "hello"
// @EXPECTED_RESULTS@: CORRECT

#include <stdio.h>

int main()
{
	printf("Hello world!\n");

	return 0;
}
